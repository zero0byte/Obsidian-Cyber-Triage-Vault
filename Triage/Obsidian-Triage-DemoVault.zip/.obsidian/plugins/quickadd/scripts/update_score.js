module.exports = async (tp) => {
  new Notice("Score calculation would happen here.");
};